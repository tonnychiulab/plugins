<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
// This plugin stores no options or custom tables.
// Reserved for future cleanup if data storage is added.
