=== Lite File Manager ===
Contributors: (your-wp-username)
Tags: file manager, wp-content, files, media
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A lightweight WordPress file manager limited to the wp-content directory, with path traversal protection, upload restrictions, and file preview.

== Description ==

Lite File Manager is a lightweight, secure WordPress admin plugin for site owners who need to manage files directly within the wp-content directory.

**Features:**

* Browse all files and folders under wp-content
* Upload files (PHP and other executable formats are blocked)
* Create new folders
* Delete files and empty folders
* Rename files and folders
* Download any file
* Preview text files and images

**Security:**

* Strict path traversal protection (realpath validation)
* All operations restricted to users with `manage_options` capability
* All forms include nonce verification
* Blocks upload of PHP, `.htaccess`, `.user.ini`, and other dangerous files

== Installation ==

1. Upload the plugin folder to the `/wp-content/plugins/` directory
2. Activate the plugin from the WordPress admin Plugins page
3. Access the plugin via the "Lite File Manager" menu in the admin sidebar

== Frequently Asked Questions ==

= Can I manage directories outside wp-content? =

No. The plugin is strictly limited to the wp-content directory and does not allow access to parent directories.

= Can I upload PHP files? =

No. PHP files and other executable formats (including `.htaccess`, `.user.ini`, and similar server configuration files) are blocked.

= Is there a file size limit? =

Single file uploads are limited to 10 MB, subject to your server's PHP `upload_max_filesize` setting.

== Changelog ==

= 1.0.0 =
* Initial release
* File browsing, upload, download, delete, rename, and folder creation
* Text file and image preview
* Strict path traversal protection and upload security checks
