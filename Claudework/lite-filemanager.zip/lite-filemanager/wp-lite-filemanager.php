<?php
/**
 * Plugin Name: Lite File Manager
 * Description: 輕量化 WordPress 檔案總管，僅限 wp-content 目錄範圍操作，含路徑穿越防護、上傳（封鎖可執行檔）、新增資料夾、刪除、重新命名與檔案預覽。無外部依賴，不影響前台效能。
 * Version:     1.0.0
 * Author:      Daily Plugin Challenge
 * License:     GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: lite-filemanager
 * Requires at least: 6.0
 * Requires PHP:      7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ============================================================
// Constants
// ============================================================

/** Root directory the file manager is allowed to operate in. */
define( 'WPLFM_ROOT', WP_CONTENT_DIR );

/** Filenames that can never be deleted or renamed (baseline safety). */
define( 'WPLFM_BLOCKED_NAMES', array( 'wp-config.php', '.htaccess', '.user.ini', '.env', 'index.php' ) );

/** Extensions blocked from upload (executables). */
define( 'WPLFM_BLOCKED_UPLOAD_EXT', array(
	'php', 'php3', 'php4', 'php5', 'php7', 'php8', 'phtml',
	'phar', 'asp', 'aspx', 'cgi', 'pl', 'py', 'rb', 'sh', 'bat',
) );

/** Maximum file size for inline text preview (512 KB). */
define( 'WPLFM_MAX_PREVIEW', 524288 );

// ============================================================
// Download — must run before any output (admin_init)
// ============================================================

add_action( 'admin_init', 'wplfm_maybe_download' );
function wplfm_maybe_download() {
	if (
		empty( $_GET['page'] )           || 'wplfm' !== $_GET['page'] ||
		empty( $_GET['wplfm_action'] )   || 'download' !== $_GET['wplfm_action'] ||
		empty( $_GET['path'] )           || empty( $_GET['_wpnonce'] )
	) {
		return;
	}

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Permission denied.' );
	}

	$raw  = sanitize_text_field( wp_unslash( $_GET['path'] ) );
	$path = wplfm_safe_path( $raw );

	if ( ! $path || ! is_file( $path ) ) {
		wp_die( 'File not found.' );
	}

	// Nonce includes the encoded path so it cannot be reused for another file
	if ( ! check_admin_referer( 'wplfm_dl_' . $raw ) ) {
		wp_die( 'Security check failed.' );
	}

	$name = basename( $path );
	nocache_headers();
	header( 'Content-Type: application/octet-stream' );
	header( 'Content-Disposition: attachment; filename="' . rawurlencode( $name ) . '"' );
	header( 'Content-Length: ' . (int) filesize( $path ) );
	// phpcs:ignore WordPress.WP.AlternativeFunctions
	readfile( $path );
	exit;
}

// ============================================================
// Activation / Deactivation
// ============================================================

register_activation_hook( __FILE__, 'wplfm_activate' );
function wplfm_activate() {
	// No setup needed currently — placeholder for future use.
}

register_deactivation_hook( __FILE__, 'wplfm_deactivate' );
function wplfm_deactivate() {
	// No teardown needed currently — placeholder for future use.
}

// ============================================================
// Admin Menu + Asset Enqueue
// ============================================================

add_action( 'admin_menu', 'wplfm_register_menu' );
function wplfm_register_menu() {
	$hook = add_menu_page(
		esc_html__( 'Lite File Manager', 'lite-filemanager' ),
		esc_html__( 'Lite File Manager', 'lite-filemanager' ),
		'manage_options',
		'wplfm',
		'wplfm_render_page',
		'dashicons-media-default',
		85
	);

	add_action( 'admin_enqueue_scripts', function ( string $page ) use ( $hook ) {
		if ( $page !== $hook ) {
			return;
		}
		wp_enqueue_script(
			'wplfm-admin',
			plugin_dir_url( __FILE__ ) . 'assets/admin.js',
			[],
			'1.0.0',
			true
		);
		wp_localize_script( 'wplfm-admin', 'wplfmI18n', [
			'rename_prompt'  => __( 'Enter new name:', 'lite-filemanager' ),
			'delete_confirm' => __( 'Delete "{n}"? This cannot be undone.', 'lite-filemanager' ),
		] );
	} );
}

// ============================================================
// WP_Filesystem Helper
// ============================================================

function wplfm_filesystem(): WP_Filesystem_Base {
	global $wp_filesystem;
	if ( ! $wp_filesystem ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		WP_Filesystem();
	}
	return $wp_filesystem;
}

// ============================================================
// Path Safety Utilities
// ============================================================

/**
 * Returns the real, validated root path (no trailing separator).
 */
function wplfm_root(): string {
	static $root = null;
	if ( null === $root ) {
		$root = rtrim( (string) realpath( WPLFM_ROOT ), DIRECTORY_SEPARATOR );
	}
	return $root;
}

/**
 * Decode a base64-encoded path, resolve with realpath(), and verify it
 * sits inside the allowed root. Returns the real path string, or false.
 *
 * @param string $encoded base64-encoded absolute path.
 * @return string|false
 */
function wplfm_safe_path( string $encoded ) {
	$decoded = base64_decode( $encoded, true );
	if ( false === $decoded ) {
		return false;
	}
	$real = realpath( $decoded );
	if ( false === $real ) {
		return false;
	}
	$root = wplfm_root();
	// Must equal root, or be directly inside it (prevent symlink escape)
	if ( $real !== $root && strpos( $real . DIRECTORY_SEPARATOR, $root . DIRECTORY_SEPARATOR ) !== 0 ) {
		return false;
	}
	return $real;
}

/**
 * Base64-encode a real path for use in URLs / hidden form fields.
 */
function wplfm_enc( string $real ): string {
	return base64_encode( $real );
}

/**
 * Read and validate the current directory from ?path=.
 * Falls back to root if invalid.
 */
function wplfm_cwd(): string {
	if ( ! empty( $_GET['path'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$raw = sanitize_text_field( wp_unslash( $_GET['path'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$dir = wplfm_safe_path( $raw );
		if ( $dir && is_dir( $dir ) ) {
			return $dir;
		}
	}
	return wplfm_root();
}

/**
 * Returns true if the basename is in the protected list.
 */
function wplfm_is_blocked( string $real ): bool {
	return in_array( basename( $real ), WPLFM_BLOCKED_NAMES, true );
}

// ============================================================
// Formatting Helpers
// ============================================================

function wplfm_fmt_size( int $b ): string {
	if ( $b < 1024 )      return $b . ' B';
	if ( $b < 1048576 )   return round( $b / 1024, 1 ) . ' KB';
	if ( $b < 1073741824 ) return round( $b / 1048576, 1 ) . ' MB';
	return round( $b / 1073741824, 1 ) . ' GB';
}

function wplfm_icon( string $path ): string {
	if ( is_dir( $path ) ) return '&#128193;'; // 📁
	$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
	$map = array(
		'php' => '&#128040;',  // 🐘 php
		'js'  => '&#9889;',   // ⚡
		'css' => '&#127912;', // 🎨
		'html'=> '&#127760;', // 🌐 htm
		'htm' => '&#127760;',
		'jpg' => '&#128247;', // 📷
		'jpeg'=> '&#128247;',
		'png' => '&#128247;',
		'gif' => '&#128247;',
		'webp'=> '&#128247;',
		'svg' => '&#128247;',
		'pdf' => '&#128196;', // 📄
		'zip' => '&#128230;', // 📦
		'gz'  => '&#128230;',
		'tar' => '&#128230;',
		'txt' => '&#128221;', // 📝
		'md'  => '&#128221;',
		'log' => '&#128203;', // 📋
		'json'=> '&#128203;',
		'xml' => '&#128203;',
		'sql' => '&#128202;', // 📊
		'csv' => '&#128202;',
	);
	return $map[ $ext ] ?? '&#128196;';
}

function wplfm_is_text( string $path ): bool {
	$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
	return in_array( $ext, array(
		'txt','md','log','json','xml','csv','html','htm','css','js','ts',
		'yaml','yml','ini','conf','gitignore','htaccess','sql','sh','bat','env',
	), true );
}

function wplfm_is_image( string $path ): bool {
	$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
	return in_array( $ext, array( 'jpg','jpeg','png','gif','webp','svg' ), true );
}

/**
 * Build breadcrumb array for the current directory.
 */
function wplfm_breadcrumbs( string $cwd ): array {
	$root  = wplfm_root();
	$parts = array( array( 'label' => 'wp-content', 'path' => $root ) );
	if ( $cwd === $root ) {
		return $parts;
	}
	$rel      = trim( str_replace( $root, '', $cwd ), DIRECTORY_SEPARATOR );
	$segments = explode( DIRECTORY_SEPARATOR, $rel );
	$built    = $root;
	foreach ( $segments as $seg ) {
		$built  .= DIRECTORY_SEPARATOR . $seg;
		$parts[] = array( 'label' => $seg, 'path' => $built );
	}
	return $parts;
}

// ============================================================
// POST Action Handlers
// ============================================================

/**
 * Dispatch POST actions. Returns error string or null on success.
 *
 * @return string|null
 */
function wplfm_handle_post() {
	if ( empty( $_POST['wplfm_action'] ) ) {
		return null;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		return __( 'Permission denied.', 'lite-filemanager' );
	}

	$act = sanitize_key( wp_unslash( $_POST['wplfm_action'] ) );

	if ( ! check_admin_referer( 'wplfm_' . $act, '_wpnonce' ) ) {
		return __( 'Security check failed. Please try again.', 'lite-filemanager' );
	}

	switch ( $act ) {
		case 'upload': return wplfm_do_upload();
		case 'mkdir':  return wplfm_do_mkdir();
		case 'delete': return wplfm_do_delete();
		case 'rename': return wplfm_do_rename();
	}
	return null;
}

function wplfm_do_upload() {
	// phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce verified in wplfm_handle_post()
	$cwd = wplfm_cwd();

	$upload_error = isset( $_FILES['upload_file']['error'] ) ? (int) $_FILES['upload_file']['error'] : UPLOAD_ERR_NO_FILE;
	if ( ! isset( $_FILES['upload_file'] ) || UPLOAD_ERR_OK !== $upload_error ) {
		return __( 'Upload error or no file selected.', 'lite-filemanager' );
	}

	$original_name = isset( $_FILES['upload_file']['name'] ) ? sanitize_file_name( wp_unslash( $_FILES['upload_file']['name'] ) ) : '';
	// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- tmp_name is server-generated, validated by is_uploaded_file()
	$tmp           = isset( $_FILES['upload_file']['tmp_name'] ) ? $_FILES['upload_file']['tmp_name'] : '';

	if ( empty( $original_name ) || empty( $tmp ) ) {
		return __( 'Invalid file data.', 'lite-filemanager' );
	}

	// Block dot-files (e.g. .htaccess, .user.ini, .env) — they have no extension
	// but can alter server/PHP behaviour and enable RCE.
	if ( str_starts_with( $original_name, '.' ) ) {
		return __( 'Uploading hidden/dot files is not allowed.', 'lite-filemanager' );
	}

	$ext = strtolower( pathinfo( $original_name, PATHINFO_EXTENSION ) );
	if ( in_array( $ext, WPLFM_BLOCKED_UPLOAD_EXT, true ) ) {
		return __( 'Uploading executable or PHP files is not allowed.', 'lite-filemanager' );
	}

	// Enforce a reasonable upload size limit (10 MB).
	$max_bytes = 10 * 1024 * 1024;
	if ( isset( $_FILES['upload_file']['size'] ) && (int) $_FILES['upload_file']['size'] > $max_bytes ) {
		return __( 'File exceeds the 10 MB upload limit.', 'lite-filemanager' );
	}

	$dest = $cwd . DIRECTORY_SEPARATOR . $original_name;

	// Prevent path traversal hidden in the filename
	if ( realpath( dirname( $dest ) ) !== $cwd ) {
		return __( 'Invalid filename.', 'lite-filemanager' );
	}

	// Verify this is a genuine PHP upload before copying (replaces move_uploaded_file security check).
	if ( ! is_uploaded_file( $tmp ) ) {
		return __( 'Invalid upload.', 'lite-filemanager' );
	}
	if ( ! wplfm_filesystem()->copy( $tmp, $dest ) ) {
		return __( 'Failed to save the uploaded file.', 'lite-filemanager' );
	}
	wp_delete_file( $tmp );
	// phpcs:enable WordPress.Security.NonceVerification.Missing
	return null;
}

function wplfm_do_mkdir() {
	// phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce verified in wplfm_handle_post()
	$cwd     = wplfm_cwd();
	$newname = sanitize_file_name( sanitize_text_field( wp_unslash( $_POST['folder_name'] ?? '' ) ) );

	if ( empty( $newname ) ) {
		return __( 'Folder name cannot be empty.', 'lite-filemanager' );
	}

	$target = $cwd . DIRECTORY_SEPARATOR . $newname;
	if ( realpath( dirname( $target ) ) !== $cwd ) {
		return __( 'Invalid folder name.', 'lite-filemanager' );
	}
	if ( file_exists( $target ) ) {
		return __( 'A file or folder with that name already exists.', 'lite-filemanager' );
	}
	// phpcs:ignore WordPress.WP.AlternativeFunctions
	if ( ! mkdir( $target, 0755 ) ) {
		return __( 'Failed to create folder.', 'lite-filemanager' );
	}
	// phpcs:enable WordPress.Security.NonceVerification.Missing
	return null;
}

function wplfm_do_delete() {
	// phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce verified in wplfm_handle_post()
	$raw  = sanitize_text_field( wp_unslash( $_POST['target_path'] ?? '' ) );
	$path = wplfm_safe_path( $raw );

	if ( ! $path )                        return __( 'Invalid path.',                       'lite-filemanager' );
	if ( wplfm_is_blocked( $path ) )      return __( 'This file is protected.',             'lite-filemanager' );
	if ( $path === wplfm_root() )         return __( 'Cannot delete the root directory.',   'lite-filemanager' );

	if ( is_dir( $path ) ) {
		$items = array_diff( (array) scandir( $path ), array( '.', '..' ) );
		if ( ! empty( $items ) ) {
			return __( 'Directory is not empty. Delete its contents first.', 'lite-filemanager' );
		}
		if ( ! wplfm_filesystem()->rmdir( $path ) ) {
			return __( 'Failed to delete directory.', 'lite-filemanager' );
		}
	} else {
		if ( ! wplfm_filesystem()->delete( $path ) ) {
			return __( 'Failed to delete file.', 'lite-filemanager' );
		}
	}
	// phpcs:enable WordPress.Security.NonceVerification.Missing
	return null;
}

function wplfm_do_rename() {
	// phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce verified in wplfm_handle_post()
	$raw     = sanitize_text_field( wp_unslash( $_POST['target_path'] ?? '' ) );
	$newname = sanitize_file_name( sanitize_text_field( wp_unslash( $_POST['new_name'] ?? '' ) ) );
	$path    = wplfm_safe_path( $raw );

	if ( ! $path || empty( $newname ) )  return __( 'Invalid path or name.',         'lite-filemanager' );
	if ( wplfm_is_blocked( $path ) )     return __( 'This file is protected.',        'lite-filemanager' );

	$new_path = dirname( $path ) . DIRECTORY_SEPARATOR . $newname;

	// Ensure the new path stays in the same directory
	if ( dirname( $new_path ) !== dirname( $path ) )  return __( 'Invalid new name.', 'lite-filemanager' );
	if ( file_exists( $new_path ) )  return __( 'A file with that name already exists.', 'lite-filemanager' );
	if ( ! wplfm_filesystem()->move( $path, $new_path ) )  return __( 'Failed to rename.', 'lite-filemanager' );
	// phpcs:enable WordPress.Security.NonceVerification.Missing

	return null;
}

// ============================================================
// Preview Page
// ============================================================

function wplfm_render_preview() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Permission denied.' );
	}

	$raw  = sanitize_text_field( wp_unslash( $_GET['path'] ?? '' ) );
	$path = wplfm_safe_path( $raw );

	if ( ! $path || ! is_file( $path ) ) {
		wp_die( esc_html__( 'File not found.', 'lite-filemanager' ) );
	}

	$name     = basename( $path );
	$back_url = admin_url( 'admin.php?page=wplfm&path=' . rawurlencode( wplfm_enc( dirname( $path ) ) ) );
	?>
	<div class="wrap">
		<p style="margin-bottom:6px">
			<a href="<?php echo esc_url( $back_url ); ?>" class="button">
				&larr; <?php esc_html_e( 'Back', 'lite-filemanager' ); ?>
			</a>
		</p>
		<h1 style="margin-top:0"><?php echo esc_html( $name ); ?></h1>

		<?php if ( wplfm_is_image( $path ) ) :
			$rel     = str_replace( WP_CONTENT_DIR, '', $path );
			$img_url = content_url( str_replace( DIRECTORY_SEPARATOR, '/', $rel ) );
		?>
			<div style="background:#f0f0f0;padding:16px;display:inline-block;border-radius:4px">
				<img src="<?php echo esc_url( $img_url ); ?>"
					 style="max-width:100%;max-height:600px;display:block"
					 alt="<?php echo esc_attr( $name ); ?>">
			</div>

		<?php elseif ( wplfm_is_text( $path ) ) :
			$size = (int) filesize( $path );
			if ( $size > WPLFM_MAX_PREVIEW ) : ?>
				<div class="notice notice-warning inline">
					<p><?php esc_html_e( 'File too large to preview (>512 KB). Please download it instead.', 'lite-filemanager' ); ?></p>
				</div>
			<?php else : ?>
				<pre style="background:#1e1e1e;color:#d4d4d4;padding:20px;overflow:auto;max-height:620px;font-size:12px;line-height:1.6;border-radius:4px;tab-size:4;white-space:pre-wrap;word-break:break-all"><?php
					// phpcs:ignore WordPress.WP.AlternativeFunctions
					echo esc_html( file_get_contents( $path ) );
				?></pre>
			<?php endif; ?>

		<?php else : ?>
			<p class="description"><?php esc_html_e( 'No preview available. Please download the file.', 'lite-filemanager' ); ?></p>
		<?php endif; ?>
	</div>
	<?php
}

// ============================================================
// Main Page
// ============================================================

function wplfm_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have sufficient permissions.', 'lite-filemanager' ) );
	}

	// Sub-page: file preview
	if (
		! empty( $_GET['wplfm_action'] ) && 'preview' === $_GET['wplfm_action'] // phpcs:ignore WordPress.Security.NonceVerification
		&& ! empty( $_GET['path'] ) // phpcs:ignore WordPress.Security.NonceVerification
	) {
		wplfm_render_preview();
		return;
	}

	// Handle POST mutations
	$notice = wplfm_handle_post();
	$notice_type = $notice ? 'error' : null;

	$cwd         = wplfm_cwd();
	$root        = wplfm_root();
	$cwd_enc     = wplfm_enc( $cwd );
	$current_url = admin_url( 'admin.php?page=wplfm&path=' . rawurlencode( $cwd_enc ) );

	// Scan directory
	$raw_items = @scandir( $cwd );
	$raw_items = $raw_items ? array_diff( $raw_items, array( '.', '..' ) ) : array();

	$dirs = $files = array();
	foreach ( $raw_items as $item ) {
		$full = $cwd . DIRECTORY_SEPARATOR . $item;
		if ( is_dir( $full ) ) {
			$dirs[] = $item;
		} else {
			$files[] = $item;
		}
	}
	sort( $dirs );
	sort( $files );
	$items = array_merge( $dirs, $files );

	$crumbs = wplfm_breadcrumbs( $cwd );
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Lite File Manager', 'lite-filemanager' ); ?>
			<span style="font-size:13px;font-weight:400;color:#888;margin-left:8px">
				<?php esc_html_e( '(wp-content only)', 'lite-filemanager' ); ?>
			</span>
		</h1>

		<?php if ( $notice ) : ?>
			<div class="notice notice-<?php echo esc_attr( $notice_type ); ?> is-dismissible">
				<p><?php echo esc_html( $notice ); ?></p>
			</div>
		<?php endif; ?>

		<!-- ── Breadcrumb ── -->
		<nav aria-label="<?php esc_attr_e( 'Directory path', 'lite-filemanager' ); ?>"
			 style="display:flex;align-items:center;flex-wrap:wrap;gap:4px;
			        margin:10px 0 14px;padding:8px 14px;
			        background:#fff;border:1px solid #ddd;border-radius:4px;font-size:13px">
			<?php foreach ( $crumbs as $i => $crumb ) : ?>
				<?php if ( $i > 0 ) : ?><span style="color:#bbb;margin:0 2px">/</span><?php endif; ?>
				<?php if ( $crumb['path'] === $cwd ) : ?>
					<strong><?php echo esc_html( $crumb['label'] ); ?></strong>
				<?php else : ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=wplfm&path=' . rawurlencode( wplfm_enc( $crumb['path'] ) ) ) ); ?>">
						<?php echo esc_html( $crumb['label'] ); ?>
					</a>
				<?php endif; ?>
			<?php endforeach; ?>
		</nav>

		<!-- ── File Table ── -->
		<table class="wp-list-table widefat striped" style="margin-bottom:20px;table-layout:fixed">
			<colgroup>
				<col style="width:32px">
				<col>
				<col style="width:88px">
				<col style="width:148px">
				<col style="width:260px">
			</colgroup>
			<thead>
				<tr>
					<th></th>
					<th><?php esc_html_e( 'Name', 'lite-filemanager' ); ?></th>
					<th><?php esc_html_e( 'Size', 'lite-filemanager' ); ?></th>
					<th><?php esc_html_e( 'Modified', 'lite-filemanager' ); ?></th>
					<th><?php esc_html_e( 'Actions', 'lite-filemanager' ); ?></th>
				</tr>
			</thead>
			<tbody>

				<?php // Up-dir row
				if ( $cwd !== $root ) : ?>
					<tr>
						<td>&#128194;</td>
						<td colspan="3">
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=wplfm&path=' . rawurlencode( wplfm_enc( dirname( $cwd ) ) ) ) ); ?>">
								../ (<?php esc_html_e( 'parent directory', 'lite-filemanager' ); ?>)
							</a>
						</td>
						<td></td>
					</tr>
				<?php endif; ?>

				<?php if ( empty( $items ) ) : ?>
					<tr>
						<td colspan="5" style="text-align:center;padding:20px;color:#888">
							<?php esc_html_e( 'This directory is empty.', 'lite-filemanager' ); ?>
						</td>
					</tr>
				<?php endif; ?>

				<?php foreach ( $items as $item ) :
					$full        = $cwd . DIRECTORY_SEPARATOR . $item;
					$is_dir      = is_dir( $full );
					$blocked     = wplfm_is_blocked( $full );
					$enc         = wplfm_enc( $full );
					$size_str    = $is_dir ? '—' : wplfm_fmt_size( (int) filesize( $full ) );
					$mtime       = date_i18n( 'Y-m-d H:i', (int) filemtime( $full ) );
					$can_preview = ! $is_dir && ( wplfm_is_text( $full ) || wplfm_is_image( $full ) );
					$dl_nonce    = wp_create_nonce( 'wplfm_dl_' . $enc );
				?>
					<tr>
						<td><?php echo wplfm_icon( $full ); // phpcs:ignore ?></td>

						<td style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
							<?php if ( $is_dir ) : ?>
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=wplfm&path=' . rawurlencode( $enc ) ) ); ?>">
									<?php echo esc_html( $item ); ?>/
								</a>
							<?php elseif ( $can_preview ) : ?>
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=wplfm&wplfm_action=preview&path=' . rawurlencode( $enc ) ) ); ?>">
									<?php echo esc_html( $item ); ?>
								</a>
							<?php else : ?>
								<?php echo esc_html( $item ); ?>
							<?php endif; ?>
						</td>

						<td style="color:#888;font-size:12px"><?php echo esc_html( $size_str ); ?></td>
						<td style="color:#888;font-size:12px"><?php echo esc_html( $mtime ); ?></td>

						<td style="white-space:nowrap">
							<?php if ( ! $is_dir ) : ?>
								<a class="button button-small"
								   href="<?php echo esc_url( admin_url( 'admin.php?page=wplfm&wplfm_action=download&path=' . rawurlencode( $enc ) . '&_wpnonce=' . $dl_nonce ) ); ?>">
									<?php esc_html_e( 'Download', 'lite-filemanager' ); ?>
								</a>
							<?php endif; ?>

							<?php if ( ! $blocked ) : ?>
								<button type="button" class="button button-small"
										data-action="rename"
										data-path="<?php echo esc_attr( $enc ); ?>"
										data-name="<?php echo esc_attr( $item ); ?>">
									<?php esc_html_e( 'Rename', 'lite-filemanager' ); ?>
								</button>
								<button type="button" class="button button-small wplfm-del"
										style="color:#c00;border-color:#c00"
										data-path="<?php echo esc_attr( $enc ); ?>"
										data-name="<?php echo esc_attr( $item ); ?>">
									<?php esc_html_e( 'Delete', 'lite-filemanager' ); ?>
								</button>
							<?php else : ?>
								<span style="font-size:11px;color:#aaa">
									<?php esc_html_e( '(protected)', 'lite-filemanager' ); ?>
								</span>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>

			</tbody>
		</table>

		<!-- ── Toolbars ── -->
		<div style="display:flex;gap:16px;flex-wrap:wrap;align-items:stretch">

			<!-- Upload -->
			<div style="flex:1;min-width:260px;background:#fff;border:1px solid #ddd;border-radius:4px;padding:16px 20px;display:flex;flex-direction:column">
				<h3 style="margin:0 0 12px;font-size:14px;font-weight:600;color:#1d2327">
					<?php esc_html_e( 'Upload File', 'lite-filemanager' ); ?>
				</h3>
				<form method="post" action="<?php echo esc_url( $current_url ); ?>" enctype="multipart/form-data" style="display:flex;flex-direction:column;flex:1">
					<?php wp_nonce_field( 'wplfm_upload', '_wpnonce' ); ?>
					<input type="hidden" name="wplfm_action" value="upload">
					<input type="file" name="upload_file" required style="display:block;width:100%;margin-bottom:0">
					<div style="margin-top:auto;padding-top:12px">
						<button type="submit" class="button button-primary">
							<?php esc_html_e( 'Upload', 'lite-filemanager' ); ?>
						</button>
						<p class="description" style="margin:6px 0 0;font-size:11px">
							<?php esc_html_e( 'PHP and other executable extensions are blocked.', 'lite-filemanager' ); ?>
						</p>
					</div>
				</form>
			</div>

			<!-- New Folder -->
			<div style="flex:1;min-width:260px;background:#fff;border:1px solid #ddd;border-radius:4px;padding:16px 20px;display:flex;flex-direction:column">
				<h3 style="margin:0 0 12px;font-size:14px;font-weight:600;color:#1d2327">
					<?php esc_html_e( 'New Folder', 'lite-filemanager' ); ?>
				</h3>
				<form method="post" action="<?php echo esc_url( $current_url ); ?>" style="display:flex;flex-direction:column;flex:1">
					<?php wp_nonce_field( 'wplfm_mkdir', '_wpnonce' ); ?>
					<input type="hidden" name="wplfm_action" value="mkdir">
					<input type="text" name="folder_name"
						   placeholder="<?php esc_attr_e( 'Folder name', 'lite-filemanager' ); ?>"
						   required class="regular-text" style="width:100%;margin-bottom:0">
					<div style="margin-top:auto;padding-top:12px">
						<button type="submit" class="button button-primary">
							<?php esc_html_e( 'Create', 'lite-filemanager' ); ?>
						</button>
						<p class="description" style="margin:6px 0 0;font-size:11px">
							<?php esc_html_e( 'Folder will be created in the current directory.', 'lite-filemanager' ); ?>
						</p>
					</div>
				</form>
			</div>

		</div>

		<!-- ── Hidden mutation forms ── -->
		<form id="wplfm-rename-form" method="post" action="<?php echo esc_url( $current_url ); ?>" style="display:none">
			<?php wp_nonce_field( 'wplfm_rename', '_wpnonce' ); ?>
			<input type="hidden" name="wplfm_action"  value="rename">
			<input type="hidden" name="target_path"   id="wplfm-rename-path">
			<input type="hidden" name="new_name"      id="wplfm-rename-newname">
		</form>

		<form id="wplfm-delete-form" method="post" action="<?php echo esc_url( $current_url ); ?>" style="display:none">
			<?php wp_nonce_field( 'wplfm_delete', '_wpnonce' ); ?>
			<input type="hidden" name="wplfm_action" value="delete">
			<input type="hidden" name="target_path"  id="wplfm-delete-path">
		</form>

	</div><!-- .wrap -->
	<?php
}

// WordPress 4.6+ auto-loads translations for plugins hosted on .org.
