/* global wplfmI18n */
(function () {
	document.querySelectorAll('[data-action="rename"]').forEach(function (btn) {
		btn.addEventListener('click', function () {
			var enc  = btn.dataset.path;
			var name = btn.dataset.name;
			var n    = prompt(wplfmI18n.rename_prompt, name);
			if (!n || n === name) return;
			document.getElementById('wplfm-rename-path').value    = enc;
			document.getElementById('wplfm-rename-newname').value = n;
			document.getElementById('wplfm-rename-form').submit();
		});
	});

	document.querySelectorAll('.wplfm-del').forEach(function (btn) {
		btn.addEventListener('click', function () {
			var msg = wplfmI18n.delete_confirm.replace('{n}', btn.dataset.name);
			if (!confirm(msg)) return;
			document.getElementById('wplfm-delete-path').value = btn.dataset.path;
			document.getElementById('wplfm-delete-form').submit();
		});
	});
}());
